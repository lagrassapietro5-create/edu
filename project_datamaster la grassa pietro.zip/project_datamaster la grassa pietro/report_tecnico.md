EduMetrics: Early Warning System

## Report Tecnico di Progetto

**Autore:** Progetto EduMetrics

**Versione:** 1.0

**Ambiente:** Python 3.10+ | MongoDB 7.0+

## 1. Istruzioni di Installazione e Configurazione

Questa sezione descrive la procedura passo-passo per replicare l'ambiente di esecuzione e l'architettura dati sulla propria macchina locale.

### 1.1 Requisiti di Sistema

* **Python**: versione 3.10 o superiore.

* **MongoDB**: versione 7.0 o superiore (Community Server) attivo su `localhost:27017`.

* **Editor/Ambiente**: Jupyter Notebook o JupyterLab.

### 1.2 Configurazione dell'Ambiente Python

1. Clonare o estrarre la cartella del progetto `EduMetrics_ProjectWork`.

2. Aprire il terminale nella cartella di radice del progetto e creare un ambiente virtuale (opzionale ma consigliato):

   ```
   python -m venv venv
   source venv/bin/activate  # Su Windows: venv\Scripts\activate
   
   ```

3. Installare le dipendenze richieste tramite il seguente comando:

   ```
   pip install pandas numpy scikit-learn pymongo matplotlib seaborn
   
   ```

### 1.3 Ripristino / Importazione del Database MongoDB

I file di dump JSON aggiornati sono posizionati nella directory `data/mongodb_dump/`. Per ripristinare il database `edumetric_db` e le sue tre collezioni, eseguire i seguenti comandi da terminale:

```
mongoimport --db=edumetric_db --collection=carriere_storico --file=data/mongodb_dump/carriere_storico.json --jsonArray
mongoimport --db=edumetric_db --collection=docenti --file=data/mongodb_dump/docenti.json --jsonArray
mongoimport --db=edumetric_db --collection=studenti --file=data/mongodb_dump/studenti.json --jsonArray

```

## 2. Credenziali Utenti di Test e Modello RBAC

Per simulare il controllo degli accessi e la sicurezza basata sui ruoli (**Role-Based Access Control - RBAC**), nella collezione `docenti` sono definiti i profili utente di seguito riportati:

| Ruolo (Role) | Username / Email | Corso / Ambito | Permessi & Visibilità | 
 | ----- | ----- | ----- | ----- | 
| **Docente / Corso** | `m.rossi@unipingu.it` | Corso di Laurea in Informatica | Accesso in sola lettura limitato agli studenti afferenti al proprio corso di insegnamento. | 
| **Tutor / Early Warning** | `g.bianchi@unipingu.it` | Commissione Orientamento & Tutorato | Accesso in lettura e scrittura per la gestione degli alert, inserimento note e monitoraggio della fascia di rischio. | 
| **System Admin** | `admin@unipingu.it` | Global / Sistema | Accesso completo con permessi di lettura/scrittura su tutte le collezioni e gestione configurazioni. | 

## 3. Schema Logico del Database MongoDB (`edumetric_db`)

Il database NoSQL `edumetric_db` è articolato in 3 collezioni interconnesse tramite identificativi univoci (`student_id` e `docente_id`):

### 3.1 Collezione `carriere_storico`

Archivia lo storico accademico e i voti conseguiti dagli studenti.

```
{
  "_id": {"$oid": "65f01a..."},
  "student_id": 1001,
  "Curricular units 1st sem (grade)": 14.5,
  "Curricular units 1st sem (approved)": 5,
  "Curricular units 2nd sem (grade)": 15.0,
  "Tuition fees up to date": 1,
  "Age at enrollment": 20,
  "platform_engagement_score": 78.4,
  "weekly_study_hours": 22.5
}

```

### 3.2 Collezione `studenti`

Raccoglie i dati anagrafici, lo stato di carriera ed il livello di rischio calcolato.

```
{
  "_id": {"$oid": "65f02b..."},
  "student_id": 1001,
  "nome": "Mario",
  "cognome": "Rossi",
  "corso_di_laurea": "Informatica",
  "stato": "Iscritto",
  "fascia_rischio": "Basso"
}

```

### 3.3 Collezione `docenti`

Contiene la gestione delle credenziali, dei permessi RBAC e dei corsi assegnati.

```
{
  "_id": {"$oid": "65f03c..."},
  "docente_id": "D001",
  "email": "m.rossi@unipingu.it",
  "ruolo": "Docente",
  "corso_assegnato": "Informatica",
  "permessi": ["read_studenti_corso"]
}

```

4. ## Spiegazione e Formulazione delle Feature Sintetiche

Per superare i limiti del dataset statico originale e simulare l'integrazione con un sistema di e-learning (Moodle/Canvas), sono state ingegnerizzate due feature sintetiche fondamentali per l'addestramento dei modelli di Regressione Multivariata e Polinomiale:

### 4.1 `platform_engagement_score` (Punteggio di Ingaggio)

Rappresenta l'indice di interazione dello studente con la piattaforma didattica online.

* **Range di valori:** $[20.0, 100.0]$

* **Formulazione stocastica:**
  

  $$
  \text{Engagement Score} \sim \mathcal{U}(20, 100)
  $$

* **Significato applicativo:** Valori inferiori a $40$ segnalano uno scarso coinvolgimento e costituiscono un fattore determinante per l'attivazione degli alert di *Early Warning*.

### 4.2 `weekly_study_hours` (Ore di Studio Settimanali)

Stima il carico di studio individuale settimanale dedicato dallo studente.

* **Range di valori:** $[5.0, 40.0]$ ore/settimana

* **Formulazione stocastica:**
  

  $$
  \text{Weekly Study Hours} \sim \mathcal{U}(5, 40)
  $$

* **Significato applicativo:** Utilizzata dai modelli regressivi in combinazione con il voto del primo semestre per catturare l'effetto di interazione sulla stima della media finale.

## 5. Sintesi dei Risultati di Valutazione del Modello

| Modello | MSE | RMSE | MAE | $R^2$ Score | 
 | ----- | ----- | ----- | ----- | ----- | 
| **Regressione Lineare Multivariata** | *Standard* | *Standard* | *Standard* | \~$82.5\%$ | 
| **Regressione Polinomiale (Grado 2)** | *Ridotto* | *Ridotto* | *Ridotto* | \~$85.1\%$ | 

Il modello Polinomiale di Grado 2 mostra un incremento nella varianza spiegata ($R^2$), dimostrando l'efficacia delle feature sintetiche e delle relazioni non lineari nel predire il rendimento accademico degli studenti.

## 6 grafici regressioni

](GRAFICI-1.png)

